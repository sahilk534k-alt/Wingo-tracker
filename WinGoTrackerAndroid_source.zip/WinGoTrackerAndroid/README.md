# WinGo Tracker Android prototype

This is an Android Studio source project for a manual WinGo results tracker with an optional floating overlay shortcut.

## Build
1. Install Android Studio (recent stable version) and Android SDK 35.
2. Open this folder as a project.
3. Allow Gradle sync to finish.
4. Select Build > Build APK(s).
5. The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
- Install the debug APK on your own Android device.
- Open WinGo Tracker and tap **Enable floating panel**.
- Grant “Display over other apps” permission in Android settings.
- Return and tap Enable again. A small `WG` bubble appears; tap it to open the tracker.
- Enter results only after rounds settle. The data is stored locally in app preferences.

## Limitations and safety
This is a prototype, not a verified predictor. It does not connect to DM First, inspect its screen, access account credentials, or place bets. The floating overlay requires explicit Android permission. It is not signed for Play Store release.
