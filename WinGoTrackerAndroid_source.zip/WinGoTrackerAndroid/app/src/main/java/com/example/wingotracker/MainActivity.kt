package com.example.wingotracker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 29)
    private val cyan = Color.rgb(34, 211, 238)
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(bg)
        }
        
        val title = TextView(this).apply {
            text = "⚡ WINGO LIVE AI PREDICTOR"
            textSize = 22f
            setTextColor(cyan)
        }
        
        val desc = TextView(this).apply {
            text = "Automated Live Period Countdown & AI Signal Generator"
            setTextColor(Color.LTGRAY)
            textSize = 14f
            setPadding(0, 8, 0, 32)
        }
        
        val startBtn = Button(this).apply {
            text = "🚀 Enable Floating AI Overlay"
            setBackgroundColor(Color.rgb(24, 95, 180))
            setTextColor(Color.WHITE)
        }
        
        val stopBtn = Button(this).apply {
            text = "Stop Floating Overlay"
            setTextColor(Color.GRAY)
        }
        
        layout.addView(title)
        layout.addView(desc)
        layout.addView(startBtn)
        layout.addView(stopBtn)
        setContentView(layout)
        
        startBtn.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Allow display over other apps, then return and tap enable.", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, FloatingPanelService::class.java))
                Toast.makeText(this, "Floating AI Predictor Enabled!", Toast.LENGTH_SHORT).show()
            }
        }
        
        stopBtn.setOnClickListener {
            stopService(Intent(this, FloatingPanelService::class.java))
            Toast.makeText(this, "Floating Overlay Stopped", Toast.LENGTH_SHORT).show()
        }
    }
}
