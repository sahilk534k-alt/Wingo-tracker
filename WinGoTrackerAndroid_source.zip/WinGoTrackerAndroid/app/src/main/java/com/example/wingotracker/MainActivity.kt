package com.example.wingotracker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private val bg = Color.rgb(8,16,32)
    private val cyan = Color.rgb(34,211,238)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,36,24,24); setBackgroundColor(bg) }
        val title = TextView(this).apply { text="DM FIRST · WINGO LAB"; textSize=24f; setTextColor(cyan) }
        val desc = TextView(this).apply { text="Manual result tracker + optional floating shortcut"; setTextColor(Color.LTGRAY); textSize=14f }
        val start = Button(this).apply { text="Enable floating panel" }
        val stop = Button(this).apply { text="Stop floating panel" }
        val note = TextView(this).apply { text="This prototype records results you enter. It does not connect to DM First, read the screen, place bets, or predict future outcomes."; setTextColor(Color.WHITE); textSize=15f; setPadding(0,24,0,0) }
        layout.addView(title); layout.addView(desc); layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                Toast.makeText(this,"Allow display over other apps, then return and tap Enable again.",Toast.LENGTH_LONG).show()
            } else { startService(Intent(this,FloatingPanelService::class.java)); Toast.makeText(this,"Floating shortcut enabled",Toast.LENGTH_SHORT).show() }
        }
        stop.setOnClickListener { stopService(Intent(this,FloatingPanelService::class.java)) }
    }
}
