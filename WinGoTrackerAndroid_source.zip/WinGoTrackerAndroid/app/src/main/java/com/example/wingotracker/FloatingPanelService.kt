package com.example.wingotracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.random.Random

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    
    private val navy = Color.rgb(10, 20, 38)
    private val cyan = Color.rgb(34, 211, 238)
    private val green = Color.rgb(34, 197, 94)
    
    private var timer: CountDownTimer? = null
    private var secondsLeft = 60
    private var currentPeriod = generatePeriodNumber()
    
    private var timerTv: TextView? = null
    private var periodTv: TextView? = null
    private var signalTv: TextView? = null
    private var numberTv: TextView? = null
    private var colorTv: TextView? = null
    
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        
        val bubbleTv = TextView(this).apply {
            text = "AI"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(16, 185, 129))
        }
        
        bubbleParams = lp(120, 120, Gravity.TOP or Gravity.START).apply {
            x = 100
            y = 300
        }
        
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        
        bubbleTv.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    bubbleParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    bubbleParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    wm.updateViewLayout(bubble, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = abs(event.rawX - initialTouchX)
                    val diffY = abs(event.rawY - initialTouchY)
                    if (diffX < 10 && diffY < 10) {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
        
        bubble = bubbleTv
        wm.addView(bubble, bubbleParams)
        
        startTimer()
    }
    
    private fun generatePeriodNumber(): String {
        val sdf = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val dateStr = sdf.format(Date())
        val gameCode = "10001" // 1-minute WinGo code
        
        val cal = Calendar.getInstance()
        val totalMinutesToday = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE) + 1
        val roundFormatted = String.format("%04d", totalMinutesToday)
        
        return "$dateStr$gameCode$roundFormatted"
    }
    
    private fun lp(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }
    
    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                secondsLeft = (millisUntilFinished / 1000).toInt()
                timerTv?.text = "⏱️ Time Remaining: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
            }
            
            override fun onFinish() {
                currentPeriod = generatePeriodNumber()
                secondsLeft = 60
                generateNextPrediction()
                startTimer()
            }
        }.start()
    }
    
    private fun generateNextPrediction() {
        val isBig = Random.nextBoolean()
        val num = if (isBig) (5..9).random() else (0..4).random()
        val colorName = if (num == 0 || num == 5) "Violet & " + (if (num == 0) "Red" else "Green") else if (num % 2 == 0) "Red" else "Green"
        
        periodTv?.text = "Period: #$currentPeriod"
        signalTv?.text = if (isBig) "BIG (5-9)" else "SMALL (0-4)"
        signalTv?.setTextColor(if (isBig) green else cyan)
        numberTv?.text = "Lucky Digit: $num"
        colorTv?.text = "Color Pattern: $colorName"
    }
    
    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }
    
    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(navy)
        }
        
        val head = TextView(this).apply {
            text = "⚡ WINGO LIVE AI PREDICTOR (DRAG TITLE TO MOVE)"
            textSize = 14f
            setTextColor(cyan)
        }
        
        periodTv = TextView(this).apply {
            text = "Period: #$currentPeriod"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, 8, 0, 4)
        }
        
        timerTv = TextView(this).apply {
            text = "⏱️ Time Remaining: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
            setTextColor(Color.YELLOW)
            textSize = 14f
            setPadding(0, 0, 0, 8)
        }
        
        val editPeriodBtn = Button(this).apply {
            text = "✏️ Set Period Base"
            setOnClickListener { showPeriodInputDialog() }
        }
        
        val syncLabel = TextView(this).apply {
            text = "ADJUST TIMER SECONDS TO MATCH GAME:"
            setTextColor(Color.LTGRAY)
            textSize = 11f
            setPadding(0, 8, 0, 0)
        }
        
        val stepLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 12)
        }
        
        val btnMinus10 = Button(this).apply { text = "-10s"; setOnClickListener { adjustTimer(-10) } }
        val btnMinus1 = Button(this).apply { text = "-1s"; setOnClickListener { adjustTimer(-1) } }
        val btnPlus1 = Button(this).apply { text = "+1s"; setOnClickListener { adjustTimer(1) } }
        val btnPlus10 = Button(this).apply { text = "+10s"; setOnClickListener { adjustTimer(10) } }
        
        stepLayout.addView(btnMinus10)
        stepLayout.addView(btnMinus1)
        stepLayout.addView(btnPlus1)
        stepLayout.addView(btnPlus10)
        
        val predBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(18, 32, 58))
        }
        
        val signalLabel = TextView(this).apply {
            text = "AI SIGNAL PREDICTION:"
            setTextColor(Color.GRAY)
            textSize = 11f
        }
        
        signalTv = TextView(this).apply {
            text = "BIG (5-9)"
            textSize = 20f
            setTextColor(green)
        }
        
        numberTv = TextView(this).apply {
            text = "Lucky Digit: 5"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        
        colorTv = TextView(this).apply {
            text = "Color Pattern: Violet & Green"
            setTextColor(Color.LTGRAY)
            textSize = 13f
        }
        
        predBox.addView(signalLabel)
        predBox.addView(signalTv)
        predBox.addView(numberTv)
        predBox.addView(colorTv)
        
        val syncBtn = Button(this).apply {
            text = "🔄 Sync Timer to Game 00:00"
            setOnClickListener {
                secondsLeft = 60
                generateNextPrediction()
                startTimer()
            }
        }
        
        val closeBtn = Button(this).apply {
            text = "Hide Panel"
            setTextColor(Color.LTGRAY)
            setOnClickListener { hidePanel() }
        }
        
        box.addView(head)
        box.addView(periodTv)
        box.addView(timerTv)
        box.addView(editPeriodBtn)
        box.addView(syncLabel)
        box.addView(stepLayout)
        box.addView(predBox)
        box.addView(syncBtn)
        box.addView(closeBtn)
        
        panel = box
        panelParams = lp((resources.displayMetrics.widthPixels * 0.90).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            x = 50
            y = 200
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        
        var panelInitialX = 0
        var panelInitialY = 0
        var panelTouchX = 0f
        var panelTouchY = 0f
        
        head.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    panelInitialX = panelParams.x
                    panelInitialY = panelParams.y
                    panelTouchX = event.rawX
                    panelTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = panelInitialX + (event.rawX - panelTouchX).toInt()
                    panelParams.y = panelInitialY + (event.rawY - panelTouchY).toInt()
                    wm.updateViewLayout(panel, panelParams)
                    true
                }
                else -> false
            }
        }
        
        wm.addView(panel, panelParams)
        generateNextPrediction()
    }
    
    private fun showPeriodInputDialog() {
        val input = EditText(this).apply {
            hint = "Enter full period or last 4 digits (e.g. 0747)"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val builder = AlertDialog.Builder(this)
            .setTitle("Set Period Number")
            .setView(input)
            .setPositiveButton("Update") { _, _ ->
                val txt = input.text.toString().trim()
                if (txt.isNotEmpty()) {
                    if (txt.length == 4 && txt.all { it.isDigit() }) {
                        val sdf = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
                        val dateStr = sdf.format(Date())
                        currentPeriod = "${dateStr}10001$txt"
                    } else {
                        currentPeriod = txt
                    }
                    periodTv?.text = "Period: #$currentPeriod"
                }
            }
            .setNegativeButton("Cancel", null)
            
        val dialog = builder.create()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        } else {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_PHONE)
        }
        dialog.show()
    }
    
    private fun adjustTimer(delta: Int) {
        secondsLeft = (secondsLeft + delta).coerceIn(1, 60)
        timerTv?.text = "⏱️ Time Remaining: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
        startTimer()
    }
    
    private fun hidePanel() {
        try { wm.removeView(panel) } catch(_: Exception) {}
        panel = null
    }
    
    private fun startForegroundServiceNotification() {
        val channelId = "wingo_ai_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "WinGo Predictor Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("WinGo AI Predictor Active")
            .setContentText("Overlay running over live game")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notification)
    }
    
    override fun onDestroy() {
        timer?.cancel()
        try { bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch(_: Exception) {}
        super.onDestroy()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
}
