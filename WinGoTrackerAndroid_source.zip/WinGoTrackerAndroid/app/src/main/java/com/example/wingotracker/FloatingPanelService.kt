package com.example.wingotracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.random.Random

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    
    private val navy = Color.rgb(10, 20, 38)
    private val cyan = Color.rgb(34, 211, 238)
    private val green = Color.rgb(34, 197, 94)
    private val red = Color.rgb(239, 68, 68)
    
    private var timer: CountDownTimer? = null
    private var secondsLeft = 60
    private var currentPeriod = 202610021000L
    
    // UI elements inside panel
    private lateinit var timerTv: TextView
    private lateinit var periodTv: TextView
    private lateinit var signalTv: TextView
    private lateinit var numberTv: TextView
    private lateinit var colorTv: TextView
    
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        
        // Floating Bubble Button
        bubble = TextView(this).apply {
            text = "AI"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(16, 185, 129))
            setOnClickListener { togglePanel() }
        }
        
        bubbleParams = lp(120, 120, Gravity.TOP or Gravity.END).apply {
            x = 20
            y = 300
        }
        wm.addView(bubble, bubbleParams)
        
        startTimer()
    }
    
    private fun lp(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }
    
    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                secondsLeft = (millisUntilFinished / 1000).toInt()
                if (::timerTv.isInitialized) {
                    timerTv.text = "⏱️ Time Remaining: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
                }
            }
            
            override fun onFinish() {
                currentPeriod++
                generateNextPrediction()
                startTimer()
            }
        }.start()
    }
    
    private fun generateNextPrediction() {
        val isBig = Random.nextBoolean()
        val num = if (isBig) (5..9).random() else (0..4).random()
        val colorName = if (num == 0 || num == 5) "Violet & " + (if (num == 0) "Red" else "Green") else if (num % 2 == 0) "Red" else "Green"
        
        if (::periodTv.isInitialized) {
            periodTv.text = "Period: #$currentPeriod"
            signalTv.text = if (isBig) "BIG (5-9)" else "SMALL (0-4)"
            signalTv.setTextColor(if (isBig) green else cyan)
            numberTv.text = "Lucky Digit: $num"
            colorTv.text = "Color Pattern: $colorName"
        }
    }
    
    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }
    
    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(navy)
        }
        
        val head = TextView(this).apply {
            text = "⚡ WINGO LIVE AI PREDICTOR"
            textSize = 16f
            setTextColor(cyan)
        }
        
        periodTv = TextView(this).apply {
            text = "Period: #$currentPeriod"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, 8, 0, 4)
        }
        
        timerTv = TextView(this).apply {
            text = "⏱️ Time Remaining: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
            setTextColor(Color.YELLOW)
            textSize = 14f
            setPadding(0, 0, 0, 12)
        }
        
        val predBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(18, 32, 58))
        }
        
        val signalLabel = TextView(this).apply {
            text = "AI SIGNAL PREDICTION:"
            setTextColor(Color.GRAY)
            textSize = 11f
        }
        
        signalTv = TextView(this).apply {
            text = "BIG (5-9)"
            textSize = 20f
            setTextColor(green)
        }
        
        numberTv = TextView(this).apply {
            text = "Lucky Digit: 7"
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        
        colorTv = TextView(this).apply {
            text = "Color Pattern: Green"
            setTextColor(Color.LTGRAY)
            textSize = 13f
        }
        
        predBox.addView(signalLabel)
        predBox.addView(signalTv)
        predBox.addView(numberTv)
        predBox.addView(colorTv)
        
        val syncBtn = Button(this).apply {
            text = "🔄 Sync / Recalculate Timer"
            setOnClickListener {
                secondsLeft = 60
                generateNextPrediction()
                startTimer()
            }
        }
        
        val closeBtn = Button(this).apply {
            text = "Hide Panel"
            setTextColor(Color.LTGRAY)
            setOnClickListener { hidePanel() }
        }
        
        box.addView(head)
        box.addView(periodTv)
        box.addView(timerTv)
        box.addView(predBox)
        box.addView(syncBtn)
        box.addView(closeBtn)
        
        panel = box
        panelParams = lp((resources.displayMetrics.widthPixels * 0.88).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        
        wm.addView(panel, panelParams)
        generateNextPrediction()
    }
    
    private fun hidePanel() {
        try { wm.removeView(panel) } catch(_: Exception) {}
        panel = null
    }
    
    private fun startForegroundServiceNotification() {
        val channelId = "wingo_ai_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "WinGo Predictor Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("WinGo AI Predictor Active")
            .setContentText("Overlay running over live game")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notification)
    }
    
    override fun onDestroy() {
        timer?.cancel()
        try { bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch(_: Exception) {}
        super.onDestroy()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
}
