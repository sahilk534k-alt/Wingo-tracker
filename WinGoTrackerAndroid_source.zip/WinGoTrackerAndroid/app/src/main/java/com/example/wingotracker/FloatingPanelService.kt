package com.example.wingotracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.random.Random

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    
    private val semiTransparentNavy = Color.parseColor("#CC0A1426") // 80% opacity dark navy
    private val cyan = Color.rgb(34, 211, 238)
    private val green = Color.rgb(34, 197, 94)
    
    private var timer: CountDownTimer? = null
    private var secondsLeft = 60
    
    // Store current numerical period to auto-increment accurately
    private var currentPeriodNum: Long = 20261001100011270L
    
    private var timerTv: TextView? = null
    private var periodTv: TextView? = null
    private var signalTv: TextView? = null
    private var numberTv: TextView? = null
    private var colorTv: TextView? = null
    
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        
        val bubbleTv = TextView(this).apply {
            text = "AI"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(16, 185, 129))
        }
        
        bubbleParams = lp(120, 120, Gravity.TOP or Gravity.START).apply {
            x = 100
            y = 300
        }
        
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        
        bubbleTv.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    bubbleParams.x = initialX + (event.rawX - initialTouchX).toInt()
                    bubbleParams.y = initialY + (event.rawY - initialTouchY).toInt()
                    wm.updateViewLayout(bubble, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val diffX = abs(event.rawX - initialTouchX)
                    val diffY = abs(event.rawY - initialTouchY)
                    if (diffX < 10 && diffY < 10) {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
        
        bubble = bubbleTv
        wm.addView(bubble, bubbleParams)
        
        startTimer()
    }
    
    private fun lp(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { this.gravity = gravity }
    
    private fun startTimer() {
        timer?.cancel()
        timer = object : CountDownTimer(secondsLeft * 1000L, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                secondsLeft = (millisUntilFinished / 1000).toInt()
                timerTv?.text = "⏱️ Time: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
            }
            
            override fun onFinish() {
                currentPeriodNum += 1
                secondsLeft = 60
                generateNextPrediction()
                startTimer()
            }
        }.start()
    }
    
    private fun generateNextPrediction() {
        val isBig = Random.nextBoolean()
        val num = if (isBig) (5..9).random() else (0..4).random()
        val colorName = if (num == 0 || num == 5) "Violet & " + (if (num == 0) "Red" else "Green") else if (num % 2 == 0) "Red" else "Green"
        
        periodTv?.text = "#$currentPeriodNum"
        signalTv?.text = if (isBig) "BIG (5-9)" else "SMALL (0-4)"
        signalTv?.setTextColor(if (isBig) green else cyan)
        numberTv?.text = "Digit: $num"
        colorTv?.text = "Color: $colorName"
    }
    
    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }
    
    private fun showPanel() {
        // Semi-transparent background with rounded corners
        val shape = GradientDrawable().apply {
            setColor(semiTransparentNavy)
            cornerRadius = 24f
        }
        
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = shape
        }
        
        val head = TextView(this).apply {
            text = "⚡ WINGO AI (DRAG)"
            textSize = 12f
            setTextColor(cyan)
        }
        
        periodTv = TextView(this).apply {
            text = "#$currentPeriodNum"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, 4, 0, 2)
        }
        
        timerTv = TextView(this).apply {
            text = "⏱️ Time: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
            setTextColor(Color.YELLOW)
            textSize = 13f
            setPadding(0, 0, 0, 6)
        }
        
        val editPeriodBtn = Button(this).apply {
            text = "✏️ Calibrate Base"
            textSize = 11f
            setOnClickListener { showPeriodInputDialog() }
        }
        
        val stepLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 4, 0, 6)
        }
        
        val btnMinus1 = Button(this).apply { text = "-1s"; textSize = 10f; setOnClickListener { adjustTimer(-1) } }
        val btnPlus1 = Button(this).apply { text = "+1s"; textSize = 10f; setOnClickListener { adjustTimer(1) } }
        
        stepLayout.addView(btnMinus1)
        stepLayout.addView(btnPlus1)
        
        val predBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.parseColor("#9912203A")) // Semi-transparent inner box
        }
        
        signalTv = TextView(this).apply {
            text = "BIG (5-9)"
            textSize = 16f
            setTextColor(green)
        }
        
        numberTv = TextView(this).apply {
            text = "Digit: 5"
            setTextColor(Color.WHITE)
            textSize = 12f
        }
        
        colorTv = TextView(this).apply {
            text = "Color: Violet & Green"
            setTextColor(Color.LTGRAY)
            textSize = 11f
        }
        
        predBox.addView(signalTv)
        predBox.addView(numberTv)
        predBox.addView(colorTv)
        
        val closeBtn = Button(this).apply {
            text = "Hide Panel"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setOnClickListener { hidePanel() }
        }
        
        box.addView(head)
        box.addView(periodTv)
        box.addView(timerTv)
        box.addView(editPeriodBtn)
        box.addView(stepLayout)
        box.addView(predBox)
        box.addView(closeBtn)
        
        panel = box
        // Reduced width to 55% of screen width for compact view
        panelParams = lp((resources.displayMetrics.widthPixels * 0.55).toInt(), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            x = 30
            y = 150
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        
        var panelInitialX = 0
        var panelInitialY = 0
        var panelTouchX = 0f
        var panelTouchY = 0f
        
        head.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    panelInitialX = panelParams.x
                    panelInitialY = panelParams.y
                    panelTouchX = event.rawX
                    panelTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    panelParams.x = panelInitialX + (event.rawX - panelTouchX).toInt()
                    panelParams.y = panelInitialY + (event.rawY - panelTouchY).toInt()
                    wm.updateViewLayout(panel, panelParams)
                    true
                }
                else -> false
            }
        }
        
        wm.addView(panel, panelParams)
        generateNextPrediction()
    }
    
    private fun showPeriodInputDialog() {
        val input = EditText(this).apply {
            hint = "e.g., 1270 or full period 20261001100011270"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val builder = AlertDialog.Builder(this)
            .setTitle("Calibrate Live Period Base")
            .setMessage("Type the current active period or last 4 digits from the game screen:")
            .setView(input)
            .setPositiveButton("Sync Base") { _, _ ->
                val txt = input.text.toString().trim()
                if (txt.isNotEmpty()) {
                    if (txt.length <= 5 && txt.all { it.isDigit() }) {
                        val basePrefix = "2026100110001"
                        currentPeriodNum = (basePrefix + txt.padStart(4, '0')).toLong()
                    } else {
                        currentPeriodNum = txt.toLongOrNull() ?: currentPeriodNum
                    }
                    periodTv?.text = "#$currentPeriodNum"
                }
            }
            .setNegativeButton("Cancel", null)
            
        val dialog = builder.create()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        } else {
            dialog.window?.setType(WindowManager.LayoutParams.TYPE_PHONE)
        }
        dialog.show()
    }
    
    private fun adjustTimer(delta: Int) {
        secondsLeft = (secondsLeft + delta).coerceIn(1, 60)
        timerTv?.text = "⏱️ Time: 00:${if (secondsLeft < 10) "0$secondsLeft" else secondsLeft}"
        startTimer()
    }
    
    private fun hidePanel() {
        try { wm.removeView(panel) } catch(_: Exception) {}
        panel = null
    }
    
    private fun startForegroundServiceNotification() {
        val channelId = "wingo_ai_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "WinGo Predictor Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("WinGo AI Predictor Active")
            .setContentText("Overlay running over live game")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, notification)
    }
    
    override fun onDestroy() {
        timer?.cancel()
        try { bubble?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch(_: Exception) {}
        super.onDestroy()
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
}
