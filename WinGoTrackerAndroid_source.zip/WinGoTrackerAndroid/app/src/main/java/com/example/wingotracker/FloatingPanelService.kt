package com.example.wingotracker

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.IBinder
import android.view.*
import android.widget.*
import android.content.Context

class FloatingPanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams
    private val prefs by lazy { getSharedPreferences("results", Context.MODE_PRIVATE) }
    private val cyan = Color.rgb(34,211,238)
    private val navy = Color.rgb(12,25,47)
    private fun lp(w:Int,h:Int,gravity:Int)=WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{this.gravity=gravity}
    override fun onCreate() {
        super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager
        bubble=TextView(this).apply { text="WG"; textSize=16f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setBackgroundColor(Color.rgb(24,95,180)); setOnClickListener{togglePanel()} }
        bubbleParams=lp(58,58,Gravity.TOP or Gravity.END).apply{x=18;y=220}
        wm.addView(bubble,bubbleParams)
    }
    private fun togglePanel(){ if(panel==null) showPanel() else { try{wm.removeView(panel)}catch(_:Exception){};panel=null } }
    private fun showPanel(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16);setBackgroundColor(navy)}
        val head=TextView(this).apply{text="WIN GO · RESULT TRACKER";textSize=18f;setTextColor(cyan)}
        val info=TextView(this).apply{text="Enter a settled result (0–9). No live game connection.";setTextColor(Color.LTGRAY);setPadding(0,8,0,8)}
        val period=EditText(this).apply{hint="Period ID (optional)";setSingleLine(true);setTextColor(Color.WHITE);setHintTextColor(Color.GRAY)}
        val spinner=Spinner(this).apply{adapter=ArrayAdapter(this@FloatingPanelService,android.R.layout.simple_spinner_dropdown_item,(0..9).map{it.toString()})}
        val save=Button(this).apply{text="Save result"}
        val stats=TextView(this).apply{setTextColor(Color.WHITE);setPadding(0,10,0,10)}
        val history=TextView(this).apply{setTextColor(Color.LTGRAY);textSize=12f}
        fun update(){
            val nums=prefs.getString("nums","")!!.split(",").filter{it.isNotBlank()}.mapNotNull{it.toIntOrNull()}
            val small=nums.count{it<5};val big=nums.size-small
            stats.text="Saved: ${nums.size}\nBig: $big · Small: $small\nObserved only—not a forecast."
            history.text="Recent: "+nums.takeLast(8).asReversed().joinToString("  ")
        }
        save.setOnClickListener{
            val old=prefs.getString("nums","")!!.trim(',');val n=spinner.selectedItem.toString()
            prefs.edit().putString("nums",if(old.isEmpty())n else "$old,$n").apply()
            period.text.clear();update()
        }
        val close=Button(this).apply{text="Hide panel";setOnClickListener{togglePanel()}}
        box.addView(head);box.addView(info);box.addView(period);box.addView(spinner);box.addView(save);box.addView(stats);box.addView(history);box.addView(close)
        panel=box
        panelParams=lp((resources.displayMetrics.widthPixels*0.88).toInt(),WindowManager.LayoutParams.WRAP_CONTENT,Gravity.CENTER)
        panelParams.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        wm.addView(panel,panelParams);update()
    }
    override fun onDestroy(){try{bubble?.let{wm.removeView(it)};panel?.let{wm.removeView(it)}}catch(_:Exception){};super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
